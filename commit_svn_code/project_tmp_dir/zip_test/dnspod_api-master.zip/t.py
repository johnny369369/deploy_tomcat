#!/usr/bin/env python3.6
# -*- coding: utf-8 -*-
import os

print(os.path.abspath(__file__))
